# Atribución formativa y límites de procedencia

## Atribución

Esta guía de UX Writing se elaboró tomando como referencia los aprendizajes, criterios y materiales compartidos durante la masterclass, el curso y la charla impartidos el **6 de noviembre de 2026** por **Antonio Estévez Funes, Conversational Designer en BBVA**, en la Escuela de Diseño Instruccional de la **Universitat Politècnica de València (UPV)**.

La sesión abordó, entre otros aspectos, la diferencia entre copywriting y UX Writing; los principios de claridad, consistencia y utilidad; la distinción entre voz y tono; el uso de lenguaje claro; la redacción de llamadas a la acción; y la relación entre UX Writing y accesibilidad.

La guía organiza y adapta esos aprendizajes para su uso como material de referencia en CUXedTech. La síntesis, la estructura, los ejemplos, las actividades y las ampliaciones didácticas son trabajo de adaptación propio y no deben atribuirse íntegramente al ponente, a BBVA ni a la UPV.

Esta atribución reconoce la procedencia formativa de los criterios. **No implica que Antonio Estévez Funes, BBVA o la UPV hayan creado, revisado, aprobado o respaldado esta guía, CUXedTech ni sus resultados.**

## Datos compartidos durante la sesión

Durante la masterclass se presentó un ejemplo de una prueba A/B del flujo de inicio de sesión y registro de Love ISDIN: según los datos compartidos por el ponente, el porcentaje de personas que entendían que podían crear una cuenta e iniciar sesión pasó del **33 %** en la pantalla original al **59 %** en la versión revisada.

Si se reproduce este dato en materiales públicos, debe atribuirse expresamente a lo compartido durante la sesión. No presentarlo como una prueba realizada por CUXedTech ni como un resultado verificado de forma independiente. Antes de publicar el nombre de la marca o detalles del caso, confirmar que existe autorización para divulgarlo; si no, describirlo de forma genérica como un ejemplo de un flujo de acceso y registro.

## Criterios tratados y aplicación responsable

- **Claridad, consistencia y utilidad:** principios para evaluar si el contenido se entiende, mantiene patrones reconocibles y ayuda a avanzar en la tarea.
- **Voz y tono:** la voz expresa la identidad verbal; el tono se adapta al contexto y al momento de la experiencia.
- **Dimensiones del tono:** la sesión hizo referencia al marco de Nielsen Norman Group. Sus cuatro escalas son formal frente a casual, serio frente a divertido, respetuoso frente a irreverente y entusiasta frente a objetivo. Referencia: Nielsen Norman Group, *The Four Dimensions of Tone of Voice* — https://www.nngroup.com/articles/tone-of-voice-dimensions/
- **Lenguaje claro:** se recomendaron la voz activa, las construcciones directas y el vocabulario sencillo. El nivel B1 se entiende como orientación práctica compartida en la sesión, no como requisito universal ni como criterio de conformidad WCAG.
- **Llamadas a la acción:** elegir un patrón verbal —por ejemplo, infinitivo o imperativo— y mantenerlo de forma coherente dentro del producto. La etiqueta debe anticipar la acción real.
- **Accesibilidad y errores:** no comunicar errores únicamente mediante el color. El mensaje debe identificar el problema y orientar sobre cómo resolverlo; el color puede complementar, pero no sustituir, la información textual y otras señales perceptibles. No convertir una recomendación de redacción en una afirmación de conformidad WCAG: la accesibilidad también depende de la implementación y debe evaluarse en contexto.

## Nota editorial

Cuando se utilicen estas ideas fuera del contexto de Travel Good, deben tratarse como principios generales de UX Writing y adaptarse al producto, las personas usuarias, el idioma, el mercado y el contexto. Los ejemplos específicos de Travel Good no deben trasladarse automáticamente a otros proyectos.
