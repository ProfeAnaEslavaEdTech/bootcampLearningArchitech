# Guía de UX Writing

## Sobre este documento

Resumen de la guía facilitada, con ejemplos adaptados a una app de viajes ficticia. Pensado como base de conocimiento para un asistente de UX Writing.

Se conservan los criterios generales de redacción, estilo, componentes, inclusión y accesibilidad. Se omiten enlaces internos, repeticiones y especificaciones particulares del sistema de diseño original. Las preferencias de estilo se presentan como orientaciones; los límites de caracteres y las convenciones visuales deben definirse para cada producto.

## 1\. Principios de comunicación

- **Claridad:** facilitar que las personas comprendan el mensaje y sepan qué hacer.  
- **Brevedad:** eliminar información superflua, rodeos y repeticiones sin perder significado.  
- **Utilidad:** aportar la información necesaria para completar la tarea.  
- **Consistencia:** mantener los mismos términos, estructuras y criterios a lo largo del producto.  
- **Empatía:** acompañar a las personas, comprender sus necesidades y evitar culpabilizarlas.  
- **Transparencia:** explicar lo que sucede con honestidad, especialmente ante problemas.  
- **Accesibilidad e inclusión:** escribir para personas con diferentes capacidades, identidades y conocimientos.

**La claridad tiene prioridad sobre la brevedad.**

## 2\. Lenguaje claro y estilo de redacción

- Escribir de forma directa, natural y conversacional.  
- Utilizar palabras cotidianas y comprensibles para el público.  
- Evitar tecnicismos, jerga, anglicismos y latinismos innecesarios. Explicar los términos especializados que deban mantenerse.  
- Priorizar frases breves y estructuras simples, con una idea principal por frase.  
- Preferir la voz activa y los verbos de acción.  
- Reducir subordinadas complejas, nominalizaciones, adverbios y perífrasis que no aporten significado.  
- Conservar los matices necesarios para expresar posibilidad, obligación, duración o condiciones.  
- Centrar el contenido en las necesidades de las personas y en la tarea que quieren realizar.  
- Evitar adjetivos vacíos, exageraciones, promesas injustificadas y presión innecesaria.  
- Aplicar lenguaje claro también en productos dirigidos a profesionales.

## 3\. Voz y tono

La voz expresa la identidad verbal de la marca. El tono se ajusta al contexto, al producto y al momento de la interacción.

- Definir el tono según el público, la tarea y el estado emocional de la persona.  
- Mantener una comunicación respetuosa y coherente durante el flujo.  
- Adaptar el humor, la formalidad, el respeto y el entusiasmo al contexto.  
- Reducir el humor y la euforia en errores, advertencias y situaciones delicadas.  
- Documentar los acuerdos de tono para que puedan aplicarse con consistencia.  
- Revisarlos cuando cambien el producto, la estrategia o las necesidades del público.

## 4\. Estilo verbal

- Preferir construcciones directas y tiempos verbales fáciles de interpretar.  
- Utilizar la segunda persona para dirigirse a quien usa el producto, adaptando el tratamiento al proyecto.  
- Utilizar la primera persona del plural cuando la organización sea quien realiza la acción.  
- Emplear el imperativo para instrucciones claras, cuidando que no resulte impositivo.  
- Preferir el infinitivo en etiquetas de acciones transaccionales, según el patrón del producto.  
- Evitar condicionales y perífrasis que alarguen el mensaje sin aportar precisión.  
- Mantenerlos cuando sean necesarios para expresar una condición real, una opción o un proceso en curso.

## 5\. Ortografía y formato

### 5.1. Mayúsculas y minúsculas

- Usar mayúscula al inicio de los enunciados y en nombres propios y siglas cuando corresponda.  
- Escribir días de la semana, meses y estaciones en minúscula.  
- Respetar los nombres establecidos para las secciones del producto.  
- Evitar frases completas en mayúsculas en el texto base.  
- Aplicar de forma consistente las convenciones del sistema de diseño.

### 5.2. Puntuación

- Puntuar las oraciones completas del cuerpo de texto.  
- Omitir el punto final en botones y, como criterio general, en titulares y etiquetas breves.  
- Usar signos de apertura y cierre en preguntas y exclamaciones.  
- Evitar exclamaciones en botones, errores e instrucciones neutras.  
- Formular preguntas cuando ayuden a tomar una decisión o mantener una conversación útil.  
- Usar paréntesis y puntos suspensivos con moderación.  
- No dejar incompleta o ambigua la información de un error o una instrucción.  
- Utilizar comillas con una función clara y un criterio coherente.

### 5.3. Negrita, cursiva y subrayado

- Usar negrita para información clave, no como decoración.  
- Mantener más texto sin destacar que destacado.  
- Evitar párrafos completos en negrita y la acumulación de estilos sobre un mismo fragmento.  
- Reservar la cursiva para palabras concretas cuando sea pertinente.  
- Reservar el subrayado para enlaces.

### 5.4. Números, fechas, horas y medidas

- Priorizar cifras en cantidades y contenidos transaccionales para facilitar el escaneo.  
- Aplicar un formato numérico consistente y adecuado al idioma y al mercado.  
- En español de España, utilizar coma decimal.  
- Separar las cifras de los símbolos monetarios, porcentajes y unidades cuando corresponda.  
- No pluralizar los símbolos ni añadirles punto.  
- Escribir fechas inequívocas y mantener el mismo patrón en cada tipo de componente.  
- Escribir los años sin separadores de millar.  
- Preferir el sistema de 24 horas y los dos puntos entre horas y minutos.  
- Expresar las duraciones de forma clara y consistente.

### 5.5. Abreviaturas, siglas y prefijos

- Evitar abreviaturas poco conocidas o ambiguas.  
- No confundir abreviaturas con siglas o símbolos de unidades.  
- Reducir las abreviaturas en titulares, botones y mensajes de error.  
- Usar siglas reconocibles para el público y explicar las que lo necesiten.  
- Aplicar las reglas ortográficas de unión, separación y acentuación de prefijos.

### 5.6. Emojis y onomatopeyas

- Utilizarlos solo cuando aporten al tono y encajen con el contexto.  
- No sustituir información o acciones por emojis.  
- Evitar emojis y onomatopeyas en botones, formularios y mensajes de error.  
- Evitar repeticiones y símbolos ambiguos.  
- Mantener el mensaje comprensible sin elementos expresivos añadidos.

## 6\. Componentes de interfaz

### 6.1. Titular, body y CTA

- **Titular:** comunicar la idea principal, la tarea o el beneficio de forma comprensible por sí misma.  
- **Body:** añadir contexto e información necesaria sin repetir el titular.  
- **CTA:** identificar la acción y permitir anticipar qué sucederá al activarla.  
- Mantener coherencia entre los tres componentes.  
- Ajustar la extensión al espacio disponible sin sacrificar información esencial.

### 6.2. Mensajes de error

- Prevenir errores mediante requisitos claros, ayuda contextual y confirmaciones útiles.  
- Explicar qué ha ocurrido y cómo continuar.  
- Adaptar el mensaje al problema concreto; evitar respuestas genéricas.  
- No culpabilizar, ridiculizar ni tratar con condescendencia a la persona.  
- Evitar jerga técnica y expresiones humorísticas que resten importancia al problema.  
- Diferenciar los errores de campo, de acción, de proceso y de plataforma.  
- Ofrecer indicaciones coherentes con las posibilidades reales del producto.

### 6.3. Notificaciones toast

- Proporcionar feedback breve sobre una acción o un estado.  
- Confirmar de forma directa, sin información redundante ni entusiasmo excesivo.  
- No incluir información esencial únicamente en mensajes que desaparecen.  
- Evitar interrumpir innecesariamente la tarea.

### 6.4. Botones y enlaces

- Utilizar etiquetas claras, breves y orientadas a la acción.  
- Mantener el mismo texto para la misma acción.  
- Diferenciar con claridad las acciones principales y secundarias.  
- Evitar etiquetas ambiguas cuando puedan confundirse la acción y su cancelación.  
- Describir el propósito o destino de los enlaces.  
- Evitar emojis, adornos y puntuación innecesaria.

### 6.5. Estados vacíos

- Explicar la ausencia de contenido y aportar contexto útil.  
- No presentar el estado vacío como un error cometido por la persona.  
- Proponer acciones pertinentes para continuar.  
- Evitar repetir la misma información en titular y body.  
- Adaptar el tono al momento del flujo; utilizar creatividad solo si mejora la experiencia.

### 6.6. Avisos en contexto y banners

- Diferenciar información, confirmación, advertencia y error.  
- Explicar con claridad la situación y, cuando proceda, la acción necesaria.  
- Mantener un tono proporcionado a la importancia del mensaje.  
- Añadir contexto o un enlace si ayuda a comprender o resolver la situación.  
- Ajustar extensión e interacción al componente definido para el producto.

### 6.7. Modales

- Centrarse en una sola decisión o mensaje relevante.  
- Redactar un titular concreto y añadir body solo cuando aporte información.  
- Explicar las consecuencias necesarias para decidir.  
- Utilizar botones inequívocos y distinguibles.  
- Evitar dobles negaciones, repeticiones y preguntas vagas.  
- Mantener coherencia con la acción que ha abierto la ventana.

### 6.8. Tooltips

- Aclarar términos o aportar contexto específico de forma breve.  
- Utilizar un tono directo e informativo.  
- No intentar explicar un flujo completo dentro del componente.  
- No dar por hecho que todas las personas leerán la ayuda emergente.  
- Mantener coherencia con el elemento que activa la explicación.

## 7\. Inclusión y accesibilidad

### 7.1. Lenguaje inclusivo

- Buscar fórmulas naturales que incluyan a todas las personas.  
- Evitar el masculino genérico cuando exista una alternativa clara y adecuada.  
- Evitar desdoblamientos y recursos gráficos que dificulten la lectura.  
- Respetar la diversidad de identidades y evitar categorías innecesarias basadas en género.  
- Revisar estereotipos en contenidos, formularios y comunicaciones.

### 7.2. Accesibilidad del contenido

- Usar vocabulario comprensible y estructuras predecibles.  
- Dividir la información en bloques breves y listas cuando faciliten la lectura.  
- Evitar dobles negaciones y construcciones complejas.  
- Preferir alineación a la izquierda y evitar texto justificado en interfaces en español.  
- Moderar los recursos tipográficos.  
- Utilizar etiquetas y enlaces descriptivos.  
- No depender únicamente del color o de elementos visuales para transmitir información.  
- Considerar la diversidad cognitiva, la dislexia y los distintos niveles de lectura.

### 7.3. Lenguaje respetuoso y antirracista

- Evitar expresiones que refuercen estereotipos raciales o culturales.  
- No asociar características físicas, orígenes o culturas con cualidades negativas.  
- Evitar exotizar o trivializar otras culturas.  
- No asumir el origen de la persona que utiliza el producto.  
- Revisar expresiones excluyentes y corregirlas con empatía.

## 8\. Checklist de revisión

- [ ] El texto se entiende con facilidad.  
- [ ] La información permite avanzar o completar la tarea.  
- [ ] No hay relleno ni repeticiones innecesarias.  
- [ ] Titular, body y CTA se complementan.  
- [ ] Los términos y las acciones son consistentes.  
- [ ] El tono corresponde al contexto y al público.  
- [ ] Los errores explican el problema y orientan hacia una solución.  
- [ ] El contenido evita sesgos y barreras de comprensión.  
- [ ] La ortografía, la puntuación y los formatos son coherentes.  
- [ ] Las negritas y otros recursos visuales tienen una función clara.  
- [ ] La extensión se ajusta al componente sin perjudicar la claridad.

## 9\. Aplicación al asistente del taller

Esta guía aporta criterios para redactar y revisar contenido de interfaces. El rol, los objetivos, el tono de respuesta, el formato de entrega y los guardarraíles del asistente se definen por separado en sus instrucciones.

Este último apartado orienta el uso didáctico del resumen; no forma parte de la guía original.

## 10\. Ejemplos adaptados a una app de viajes

Los siguientes ejemplos trasladan las situaciones de la guía original —registro, compra, recompensas, formularios y notificaciones— a búsquedas, reservas y viajes. Son propuestas didácticas, no textos extraídos de una app real.

**Contexto del ejercicio:** la app permite buscar y reservar alojamientos, guardar favoritos y consultar reservas. Las condiciones de cancelación, importes y plazos que aparezcan en un caso son datos ficticios de ese caso; no deben aplicarse a otras reservas.

### 10.1. Lenguaje claro, directo y útil

| Criterio | Texto mejorable | Propuesta | Motivo |
| :---- | :---- | :---- | :---- |
| Lenguaje cotidiano | Esta funcionalidad permite la visualización de tus reservas. | Consulta tus reservas. | Sustituye jerga y nominalizaciones por una acción clara. |
| Voz activa | La confirmación de tu reserva será enviada por nuestro equipo. | Te enviaremos la confirmación de tu reserva. | Identifica quién actúa y reduce la complejidad. |
| Brevedad | En este momento no dispones de ningún alojamiento añadido a tu lista de favoritos. | Aún no tienes alojamientos favoritos. | Elimina palabras que no aportan información. |
| Acción y beneficio | Si creas una cuenta, podrás guardar los alojamientos que te interesen. | Crea una cuenta para guardar tus alojamientos favoritos. | Conecta la acción con su utilidad. La primera versión también es válida. |
| Opcionalidad | Añade el número de vuelo. | Puedes añadir el número de vuelo. | Aclara que el dato es opcional en este caso. |
| Información concreta | Tu viaje está casi listo. | Revisa los datos antes de pagar. | Indica la tarea real de esta pantalla. |
| Confirmación | Tu reserva ha sido realizada correctamente con éxito. | Reserva confirmada. | Evita redundancias; solo se usa cuando la reserva está confirmada. |
| Transparencia | ¡Reserva ahora o perderás esta oportunidad única\! | Consulta la disponibilidad para tus fechas. | Elimina presión y escasez no demostradas. |

### 10.2. Hero zone: titular, body y CTA

**Situación:** pantalla que invita a crear una cuenta para guardar alojamientos. No implica reservar ni pagar.

**Versión mejorable**

- **Titular:** Vive experiencias inolvidables  
- **Body:** Descubre experiencias únicas y disfruta de tus próximas aventuras.  
- **CTA:** Quiero vivirlo

**Propuesta**

- **Titular:** Guarda los alojamientos que te gustan  
- **Body:** Crea una cuenta para reunir tus favoritos y consultarlos cuando prepares tu viaje.  
- **CTA:** Crear cuenta

**Por qué:** el titular explica el beneficio, el body indica cómo obtenerlo y el botón nombra la acción real.

### 10.3. Mensajes de error

| Situación del ejercicio | Texto mejorable | Propuesta |
| :---- | :---- | :---- |
| Falta el destino | Campo obligatorio. | Indica el destino para buscar alojamientos. |
| La salida es anterior a la entrada | Fecha inválida. | Elige una fecha de salida posterior a la de entrada. |
| El correo no tiene el formato requerido | Has escrito mal tu email. | Revisa el correo electrónico. Debe incluir una @ y un dominio. |
| Se ha perdido la conexión y no carga la búsqueda | ¡Ups\! Algo ha salido mal. | No hemos podido cargar los alojamientos. Comprueba tu conexión y vuelve a intentarlo. |
| El alojamiento ya no está disponible para las fechas elegidas | Error de disponibilidad. | Este alojamiento ya no está disponible para tus fechas. Elige otras fechas o busca otro alojamiento. |

**Caso de pago:** el sistema confirma que el pago ha fallado y que no se ha efectuado ningún cargo.

- **Titular:** No hemos podido completar el pago  
- **Body:** No se ha realizado ningún cargo. Prueba con otro método de pago.  
- **CTA:** Cambiar método de pago

No afirmar que no existe un cargo si el sistema no lo confirma. Si el estado del pago es incierto, el mensaje debe reflejarlo y ofrecer la vía de comprobación disponible.

### 10.4. Notificaciones toast

| Acción completada | Texto mejorable | Propuesta |
| :---- | :---- | :---- |
| Guardar un alojamiento | ¡Enhorabuena\! Tu alojamiento ha sido añadido correctamente a favoritos. | Alojamiento guardado en favoritos. |
| Quitar un favorito | El elemento seleccionado ha sido eliminado con éxito. | Alojamiento eliminado de favoritos. |
| Guardar un cambio de teléfono | Tus datos han sido actualizados correctamente. | Teléfono actualizado. |

La confirmación de una reserva y sus condiciones deben poder consultarse en un espacio persistente; no deben depender de una notificación temporal.

### 10.5. Botones y enlaces

| Acción o destino | Texto mejorable | Propuesta |
| :---- | :---- | :---- |
| Crear una cuenta | Quiero empezar mi aventura | Crear cuenta |
| Buscar alojamientos | Vamos allá | Buscar alojamientos |
| Consultar una reserva | Ver más | Ver reserva |
| Descargar un justificante | Haz clic aquí | Descargar justificante |
| Acceder a las condiciones de cancelación | Más información | Consultar condiciones de cancelación |
| Pagar una reserva | Continuar | Pagar y reservar |

El último botón solo corresponde a un paso que realmente inicia el pago y la reserva. Si abre una pantalla de revisión, debe nombrar esa acción.

### 10.6. Estados vacíos

**Caso A: todavía no hay favoritos**

- **Titular:** Aún no tienes alojamientos favoritos  
- **Body:** Guarda los que te gusten para encontrarlos cuando prepares tu viaje.  
- **CTA:** Buscar alojamientos

**Caso B: no hay resultados con los filtros seleccionados**

- **Titular:** No hay alojamientos con estos filtros  
- **Body:** Elimina algún filtro para ampliar la búsqueda.  
- **CTA:** Quitar filtros

**Caso C: no hay reservas próximas**

- **Titular:** No tienes próximas reservas  
- **Body:** Busca un alojamiento para tu siguiente viaje o consulta tus reservas anteriores.  
- **CTA principal:** Buscar alojamientos  
- **Enlace secundario:** Ver reservas anteriores

Son situaciones diferentes: el primer uso, una búsqueda sin resultados y la ausencia de actividad próxima necesitan mensajes distintos.

### 10.7. Avisos en contexto y banners

**Aviso de un requisito pendiente**

- **Texto:** Añade el nombre de la persona titular de la reserva para continuar.  
- **Ubicación:** junto al campo correspondiente.

**Banner informativo**

- **Texto:** Este alojamiento cobra la tasa turística al llegar. Consulta el importe antes de reservar.  
- **Enlace:** Ver tasa turística  
- **Condición del caso:** el importe está disponible en el destino del enlace.

**Banner de advertencia**

- **Texto:** Esta tarifa no permite cancelar ni cambiar las fechas. Revisa las condiciones antes de pagar.  
- **Enlace:** Consultar condiciones  
- **Condición del caso:** estas restricciones corresponden a la tarifa seleccionada.

### 10.8. Modal de cancelación

**Situación:** la persona va a cancelar una reserva cuya tarifa permite hacerlo sin coste en ese momento.

**Versión mejorable**

- **Titular:** ¿Estás seguro?  
- **Body:** Vas a cancelar. ¿Quieres continuar?  
- **Botones:** Sí / Cancelar

**Propuesta**

- **Titular:** ¿Quieres cancelar tu reserva en Sevilla?  
- **Body:** Puedes cancelarla sin coste. Si quieres conservarla, vuelve a tu reserva.  
- **CTA principal:** Cancelar reserva  
- **CTA secundario:** Mantener reserva

**Por qué:** identifica qué se cancela y distingue las dos decisiones. No promete un reembolso ni un plazo, porque el caso no aporta esos datos.

### 10.9. Tooltips y ayuda contextual

| Elemento | Texto de ayuda |
| :---- | :---- |
| Precio por noche | Importe del alojamiento para una noche. |
| Número de reserva | Código que identifica tu reserva. Lo encontrarás en el correo de confirmación. |
| Habitaciones comunicadas | Habitaciones conectadas por una puerta interior. |

Las condiciones importantes sobre tasas, cancelación o pagos deben estar visibles antes de confirmar la reserva; una ayuda emergente no basta para comunicarlas.

### 10.10. Inclusión y accesibilidad

| Texto mejorable | Propuesta | Criterio |
| :---- | :---- | :---- |
| Bienvenido a tu próxima aventura | Te damos la bienvenida | Evitar marcar género cuando no es necesario. |
| Invita a tus amigos al viaje | Invita a quien quieras al viaje | Incluir diferentes relaciones y personas. |
| Te mantendremos informado sobre tu reserva | Te mantendremos al día sobre tu reserva | Evitar el masculino genérico. |
| ¿Estás segur@ de cancelar? | ¿Quieres cancelar tu reserva? | Formular una decisión clara y legible. |
| Pulsa el botón verde para seguir | Selecciona Continuar para revisar tu reserva | No depender del color. |
| Haz clic aquí | Consultar detalles del alojamiento | Describir el destino del enlace. |
| No olvides desmarcar la casilla si no quieres recibir ofertas | Marca esta casilla si quieres recibir ofertas | Evitar dobles negaciones. Esta propuesta requiere que la casilla no esté marcada por defecto. |

### 10.11. Fechas, cantidades y formato

Los valores siguientes son ficticios y solo muestran criterios de escritura.

| Texto mejorable | Propuesta |
| :---- | :---- |
| Precio: 95.50€ | Precio: 95,50 € |
| Descuento del 15% | Descuento del 15 % |
| Entrada: Viernes 12 de Marzo | Entrada: viernes 12 de marzo |
| Hora de entrada: 6:00 PM | Hora de entrada: 18:00 |
| Duración: 2 hrs. y 30 mins. | Duración: 2 h y 30 min |
| ¡RESERVA CONFIRMADA\! | Reserva confirmada |

### 10.12. Coherencia del tono

- **Exploración:** «Encuentra un alojamiento para tu próxima escapada».  
- **Confirmación:** «Tu reserva está confirmada. Consulta los detalles de tu estancia».  
- **Incidencia:** «No hemos podido cargar tu reserva. Vuelve a intentarlo».  
- **Decisión importante:** «Revisa las condiciones de cancelación antes de pagar».

El tono puede ser más cálido durante la exploración y más sobrio en una incidencia. En todos los casos debe mantener claridad, respeto y utilidad. Las acciones de recuperación solo se proponen cuando el producto las permite.

## 11\. Consistencia: construir un vocabulario de producto

Este apartado amplía el principio de consistencia desarrollado en la guía original. Los ejemplos y el glosario siguientes son propuestas para el ejercicio de viajes.

La consistencia reduce el esfuerzo de aprendizaje: una persona no debería preguntarse si dos palabras distintas describen la misma acción. Se aplica al vocabulario, a las estructuras, a la puntuación y a la relación entre componentes.

### 11.1. Misma acción, mismo término

- Elegir un verbo para cada acción principal y mantenerlo durante todo el recorrido.  
- No cambiar palabras por sinónimos solo para evitar repeticiones.  
- Diferenciar acciones realmente distintas, aunque se parezcan.  
- Repetir estructuras reconocibles en componentes equivalentes.  
- Documentar las excepciones y dónde se aplican.

### 11.2. Glosario inicial para la app de viajes

| Término acordado | Uso | Evitar confundirlo con |
| :---- | :---- | :---- |
| Alojamiento | Término general para los establecimientos que se pueden reservar. | Hotel, cuando el catálogo también incluye apartamentos u otros tipos. |
| Reserva | Contratación de una estancia. | Viaje, que puede incluir más elementos. |
| Favoritos | Alojamientos que la persona guarda para consultar después. | Reservas confirmadas. |
| Guardar en favoritos | Añadir un alojamiento a la lista de favoritos. | Reservar, que implica otro proceso. |
| Cancelar reserva | Iniciar la cancelación de una reserva. | Cerrar una ventana o volver a la pantalla anterior. |
| Eliminar de favoritos | Quitar un alojamiento de la lista. | Cancelar una reserva. |
| Fecha de entrada | Día en el que comienza la estancia. | Hora de entrada. |
| Fecha de salida | Día en el que termina la estancia. | Fecha del viaje de vuelta. |

Este glosario es un punto de partida del taller, no una lista extraída del documento original. Se ampliará cuando el producto necesite nuevos conceptos.

### 11.3. Titular y CTA como conjunto

| Titular | CTA coherente | CTA que genera dudas |
| :---- | :---- | :---- |
| Crea una cuenta para guardar tus favoritos | Crear cuenta | Empezar |
| ¿Quieres eliminar este alojamiento de favoritos? | Eliminar de favoritos | Cancelar |
| Revisa los datos de tu reserva | Revisar datos | Confirmar viaje |

La coincidencia de vocabulario ayuda a anticipar la acción. No es necesario repetir literalmente todo el titular en el botón.

## 12\. Definir y documentar el tono

La guía original propone analizar el producto, acordar el tono en una sesión de trabajo y documentarlo. Esta sección recupera ese método de forma resumida.

### 12.1. Tres pasos

1. **Analizar:** revisar pantallas, comunicaciones y guías disponibles. Identificar el público y los momentos importantes del recorrido.  
2. **Acordar:** contrastar las decisiones entre contenido, diseño y research, incorporando las necesidades de negocio y las restricciones relevantes.  
3. **Documentar:** describir las decisiones con criterios y ejemplos. Revisarlas cuando cambie el producto y contrastarlas con personas usuarias.

### 12.2. Cuatro dimensiones

| Dimensión | Pregunta para decidir | Aplicación propuesta a la app de viajes |
| :---- | :---- | :---- |
| Humor | ¿Cuándo puede ayudar y cuándo distrae? | Ligero durante la exploración; ausente en problemas de pago o cancelación. |
| Formalidad | ¿Qué grado de cercanía necesita el público? | Lenguaje natural, tratamiento de tú y ausencia de jerga administrativa. |
| Respeto | ¿Cómo evitar la condescendencia o una familiaridad excesiva? | Acompañar sin juzgar las elecciones, el presupuesto o la experiencia de viaje. |
| Entusiasmo | ¿Cuánta emoción necesita cada momento? | Mayor en la inspiración y moderado en confirmaciones y tareas funcionales. |

Estas son decisiones propuestas para la app ficticia. El alumnado puede modificarlas y comprobar sus efectos.

### 12.3. Convertir adjetivos en instrucciones observables

| Intención | Instrucción concreta |
| :---- | :---- |
| Cercano | Dirígete de tú a la persona y utiliza vocabulario cotidiano. |
| Claro | Explica primero qué ocurre y después qué puede hacer. |
| Empático | No atribuyas culpa a la persona en los mensajes de error. |
| Entusiasta | Expresa ilusión en contenidos de descubrimiento, sin exagerar beneficios ni añadir presión. |

Evitar definiciones que cada persona pueda interpretar de forma distinta sin ejemplos que las concreten.

## 13\. Prevenir errores antes de tener que explicarlos

La guía original destaca que la redacción también ayuda a prevenir errores. Para ello, contenido debe trabajar con diseño y desarrollo: algunas soluciones requieren cambios de interacción.

| Recurso | Aplicación a la app de viajes | Qué debe confirmar el equipo |
| :---- | :---- | :---- |
| Ayuda previa | Explicar los requisitos de la contraseña antes de que se envíe el formulario. | Los requisitos reales del sistema. |
| Restricciones útiles | Evitar seleccionar una salida anterior a la entrada. | El comportamiento del calendario y sus alternativas accesibles. |
| Confirmación de resultado | Mostrar que la reserva se ha confirmado y dónde consultarla. | El estado real de la reserva. |
| Revisión previa | Permitir revisar destino, fechas, personas e importe antes de pagar. | Los datos que se pueden editar en ese paso. |
| Corrección o vuelta atrás | Permitir corregir un dato sin perder lo que ya se ha completado. | Si el sistema conserva la información. |

### 13.1. Separar etiqueta, ayuda y error

**Caso ficticio: crear una contraseña con un mínimo de 12 caracteres.**

- **Etiqueta:** Contraseña  
- **Ayuda previa:** Utiliza al menos 12 caracteres.  
- **Error tras validar:** La contraseña tiene menos de 12 caracteres. Añade los que faltan para continuar.

La ayuda anticipa el requisito; el error explica el incumplimiento concreto. No reutilizar este requisito fuera del ejemplo si el sistema exige otro.

## 14\. Escribir para una diversidad de personas y viajes

Ampliación de los apartados de inclusión, accesibilidad y lenguaje antirracista de la guía original, con situaciones nuevas de la app de viajes.

### 14.1. No dar por hecho con quién viaja una persona

| Texto mejorable | Propuesta | Motivo |
| :---- | :---- | :---- |
| Reserva la escapada perfecta para ti y tu pareja | Encuentra alojamiento para tu próxima escapada | No presupone una relación o una forma de viajar. |
| Papá y mamá también necesitan vacaciones | Encuentra alojamiento para viajar en familia | Evita presentar una única estructura familiar. |
| Introduce tu nombre cristiano | Nombre | Evita una referencia religiosa innecesaria. |

La propuesta sobre familias corresponde a una sección dedicada a ese tipo de viaje; en una búsqueda general bastaría con hablar de personas o huéspedes.

### 14.2. Formularios: pedir solo lo necesario

- Revisar para qué se solicita cada dato antes de redactar la pregunta.  
- No deducir género, tratamiento o nacionalidad a partir del nombre.  
- Evitar clasificaciones por género cuando no aporten a la tarea.  
- Si el dato es opcional, comunicarlo con claridad.  
- No sustituir un dato por otro de significado distinto para que parezca más inclusivo.

**Ejemplo:** si la reserva solo requiere identificar a su titular, utilizar «Nombre» y «Apellidos», sin añadir tratamientos innecesarios.

### 14.3. Describir destinos con precisión

| Texto mejorable | Propuesta orientativa |
| :---- | :---- |
| Descubre una cultura primitiva | Descubre la historia y las tradiciones locales |
| Conoce a sus exóticos habitantes | Conoce la vida local a través de visitas guiadas |

La segunda propuesta solo es válida si esas visitas existen. El contenido debe describir actividades y lugares concretos, sin exotizar a las personas ni atribuir características a toda una comunidad.

## 15\. Documentar patrones y mantener la guía

La guía original remite a documentación específica de términos, errores y componentes. Para el taller, podemos convertir esa práctica en una ficha sencilla y reutilizable.

### 15.1. Ficha de contenido

| Campo | Qué registrar |
| :---- | :---- |
| Situación | Qué ha ocurrido o qué tarea quiere completar la persona. |
| Componente | Dónde aparecerá el mensaje. |
| Texto | La propuesta aprobada. |
| Acción | Qué ocurre al activar el botón o enlace. |
| Condiciones | Qué datos deben ser ciertos para mostrar el mensaje. |
| Tono | Qué decisiones de tono se aplican en ese contexto. |
| Restricciones | Límites de espacio, variables y requisitos del producto. |

### 15.2. Ficha de ejemplo

- **Situación:** la persona ha guardado un alojamiento en favoritos.  
- **Componente:** toast.  
- **Texto:** Alojamiento guardado en favoritos.  
- **Acción:** no requiere ninguna acción adicional.  
- **Condiciones:** el sistema ha confirmado que el alojamiento se ha guardado.  
- **Tono:** directo y tranquilo.  
- **Restricciones:** no incluir información necesaria para reservar; los favoritos deben poder consultarse en su sección.

### 15.3. Revisión final ampliada

Además del checklist anterior, comprobar:

- [ ] El mismo concepto conserva su nombre entre pantallas y comunicaciones.  
- [ ] Se distingue entre una acción pendiente, una acción en curso y una acción completada.  
- [ ] Los datos necesarios para decidir aparecen antes de la acción.  
- [ ] Las instrucciones coinciden con controles y opciones que realmente existen.  
- [ ] Los errores se han prevenido cuando era posible.  
- [ ] Las excepciones de estilo están documentadas.  
- [ ] El contenido se ha leído en voz alta para detectar frases poco naturales.  
- [ ] Las dudas que necesitan validación con personas usuarias están identificadas.

Los ejemplos, glosarios y fichas de esta ampliación son adaptaciones didácticas. Los principios de consistencia, definición del tono, prevención de errores, inclusión y documentación proceden de la guía facilitada.