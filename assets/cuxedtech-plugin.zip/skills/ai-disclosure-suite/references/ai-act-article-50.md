# EU AI Act — Article 50 legal reference

Regulation (EU) 2024/1689 (the "AI Act"). Entered into force 1 August 2024.
**Article 50 transparency obligations apply since 2 August 2026** (a limited
grace period until 2 December 2026 exists only for machine-readable marking
of systems placed on the market before August 2026 — a provider matter).

## Roles

- **Provider**: develops or supplies the AI system/tool (e.g. OpenAI,
  Midjourney, ElevenLabs, Adobe). Bears Art. 50(1) design duties and Art.
  50(2) machine-readable marking duties.
- **Deployer**: uses an AI system under their own authority in a
  professional activity. **Ana, as an autónoma using AI tools to create
  teaching materials, is a deployer.** Her duties come from Art. 50(3)
  (not relevant to her — emotion recognition/biometrics) and Art. 50(4).

## Article 50, paragraph by paragraph

**50(1) — Interaction with AI.** Providers must design systems so people know
they are interacting with AI, unless obvious to a reasonably well-informed
person. Practical consequence for Ana: any student-facing chatbot she deploys
in a course should be clearly labelled as AI.

**50(2) — Machine-readable marking.** Providers of generative systems must
mark outputs (watermarks/metadata) as artificially generated. **This is not
Ana's obligation.** Exceptions: assistive editing functions, systems that do
not substantially alter the input.

**50(3) — Emotion recognition / biometric categorisation.** Deployers must
inform exposed persons. Not applicable to her current work.

**50(4) — Deepfakes and AI-generated text (deployer duties).**
- *Deepfakes* (image/audio/video that resembles real persons, objects,
  places or events and would falsely appear authentic): the deployer must
  disclose that the content has been artificially generated or manipulated.
  Exception: evidently artistic, creative, satirical or fictional works
  (disclosure then only needs to be made in an appropriate, non-hampering
  way).
- *Text*: disclosure is required only for AI-generated text **published with
  the purpose of informing the public on matters of public interest**, and
  even then it is **exempt where the content has undergone human review or
  editorial control and a natural or legal person holds editorial
  responsibility**. Per the Commission's 2026 guidance, qualifying review
  means deliberate examination with authority to approve, alter or reject
  the substance — not mere spell-checking. Ana's pedagogical review, level
  adaptation (e.g. CEFR grading) and correction of model output clearly
  qualifies. Teaching materials for enrolled students are additionally hard
  to characterise as "informing the public on matters of public interest" at
  all.

**50(5) — Manner of disclosure.** Information must be provided in a clear and
distinguishable manner **at the latest at the time of first interaction or
exposure**, and meet accessibility requirements. This is why a cloned-voice
or avatar lesson needs an up-front on-screen/spoken notice, not only a
footnote.

**50(6)** — These duties add to, and do not replace, other EU/national rules.
**50(7)** — The AI Office encourages codes of practice for labelling.

## Penalties

Non-compliance with Article 50 obligations can attract fines of up to
€15 million or 3 % of worldwide annual turnover (the €35 million / 7 % tier
is reserved for prohibited practices under Art. 5). Do not quote the €35M
figure for transparency breaches.

## Spain

Spain enforces the AI Act through AESIA (Agencia Española de Supervisión de
la Inteligencia Artificial). A national implementing law (anteproyecto de ley
de gobernanza de la IA) aligns national sanctions with the Regulation. As an
autónoma, Ana is subject to the Regulation directly; no separate Spanish
registration for AI use is required.

## Useful citation forms

- Long: "Article 50 of Regulation (EU) 2024/1689 (EU Artificial Intelligence
  Act)"
- Short: "EU AI Act, Art. 50(4)"
- Spanish: "art. 50 del Reglamento (UE) 2024/1689 (Ley de IA)"

## Sources consulted (June–August 2026)

- Commission FAQ: digital-strategy.ec.europa.eu — "Transparency obligations
  under Article 50 of the AI Act"
- artificialintelligenceact.eu/article/50/
- Commission guidelines on transparency for AI-generated content (2026)
