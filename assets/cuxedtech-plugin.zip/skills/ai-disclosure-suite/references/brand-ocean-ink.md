# Ocean Ink — Ana's brand palette for disclosure elements

Source: "Ocean Ink Palette System" v0.1 (6 Aug 2026), profeanaeslavaedtech.
One palette unifies website, portfolio, LinkedIn, CV, Instagram, courses and
apps. Apply it whenever a disclosure note is rendered visually (PDF footer,
slide credit, HTML banner, course credits page) rather than as plain text.

## Core colours

| Token | Light theme | Dark theme | Use |
|---|---|---|---|
| --ink (text) | #1C1E2E | #EEF0F8 | Body text, footnote text |
| --canvas | #F7F8FC | #0F1120 | Page background |
| --surface | #FFFFFF | #171A2B | Cards, note boxes |
| --line | #E6E8F2 | #2A2D44 | The rule above a footnote |
| --muted | #5B5F77 | #A6ADC8 | Footnote / small print colour |
| --primary (Indigo Blue) | #3B5BD6 | #9DB2FF | Links, emphasis |
| --primary-deep | #22307C | #B9C8F6 | Headings |
| --accent (Gold) | #E8A33D | #EEC272 | Attention, use sparingly |
| --accent-text | #9A5B00 | #EEC272 | Gold at body size on light |
| --success (Rose) | #8B3A52 | #E0A6B8 | Progress/confirmation only |

## Typography

- **Fraunces** 600–700 — display, H1–H2 (classic, senior register).
- **Inter** 400–700 — H3, UI, body, and footnotes.
- Both on Google Fonts, so they work in Canva, Articulate Rise, Moodle,
  Chamilo, Google Sites and web builds.
- Body 15–17 px, line-height 1.6; footnotes may go smaller but must keep
  WCAG contrast.

## Rules that matter for disclosure elements

1. Footnote/small-print text in **muted** (#5B5F77 on light — 5.91:1 AA),
   never pure grey (neutrals are tinted, not grey) and never pure black.
2. Colour never carries meaning alone — an AI-disclosure banner should pair
   colour with an icon or label (e.g. "⚙️" or "AI"), per WCAG 1.4.1.
3. One gold accent per screen. A disclosure banner may use gold to draw
   attention (e.g. the mandatory avatar/deepfake notice) but then nothing
   else on that surface uses gold. On light backgrounds, gold text at body
   size must be gold-600 #9A5B00.
4. Errors/attention in amber, never red (affective filter). Never use red
   for the disclosure notice.
5. Dual theme: if producing HTML, declare the light set on `:root` and the
   dark set under `[data-theme="dark"]`; never invert one to get the other.
6. The signature gradient (#3B5BD6 → #E8A33D, 135°) is for hero bands only —
   at most one per page; do not use it on footnotes.
7. Minimum tap target 44×44 px if the disclosure is interactive (an "About
   this AI" link or expandable notice).

## Ready-made styling recipes

**PDF / document footnote:** Inter, 1 pt rule in --line above the note,
text in --muted, article citation optionally in --primary.

**Slide-corner credit (Canva):** Inter 10–12 px in --muted; if the slide is
dark-themed use #A6ADC8. No gradient, no gold.

**Mandatory notice banner (avatar/deepfake or chatbot):** surface card with
gold left border (#E8A33D) + "!" or "AI" glyph, heading in --primary-deep
(Fraunces), body in --ink. This mirrors her "state-attention" pattern
(needs attention, never alarming red).

**Course credits page (Moodle/Rise):** H2 in Fraunces --primary-deep
("Transparency & credits / Transparencia y créditos"), body in Inter --ink,
methodology block bullets with "•".
