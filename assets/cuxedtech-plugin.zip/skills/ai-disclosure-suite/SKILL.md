---
name: "ai-disclosure-suite"
description: "Single entry point for AI disclosure: EU AI Act Art. 50 notes for Ana's teaching materials and LinkedIn posts, and Elsevier AI declarations for journal manuscripts. Use instead of either separate skill."
---

# AI Disclosure Suite

Replaces two earlier skills, `ai-act-disclosure-notes` (teaching materials, EU AI Act) and `ai-for-authors` (Elsevier journal manuscripts), which can be retired. Ana Eslava-Graterol is an EFL teacher and instructional designer, registered self-employed professional (*autónoma*) in Spain, so EU law applies directly. Responses are in English; the Spanish note texts below are deliverables for her materials, offered alongside the English unless she says English only.

For exact EU AI Act article text, exemptions, dates and fines, read `references/ai-act-article-50.md`. When a note is rendered visually (styled PDF footer, slide credit, HTML banner, course credits page), read `references/brand-ocean-ink.md` and style it with the Ocean Ink brand (Fraunces + Inter, indigo/gold/rose, WCAG-checked). Plain-text destinations (LinkedIn, e-mail) do not need it.

## Step 0. Route the request

| What is being disclosed | Track |
|---|---|
| Worksheets, slides, PDFs, e-learning, audio, video, chatbots, LinkedIn or social posts | **Track 1: EU AI Act (law)** |
| A manuscript, figure or graphical abstract for an Elsevier journal | **Track 2: Elsevier policy (publisher rule)** |
| Both (e.g. a paper about her AI-assisted teaching materials) | Run both tracks separately and keep the wording distinct |

If unclear, ask one short question.

**Honesty rules that apply to both tracks**
- The EU AI Act is law. Elsevier's policy is a publisher requirement. Never describe an Elsevier requirement as "required by law", and never describe a voluntary note under the AI Act as legally required.
- Under Art. 50(2), watermarking or machine-readable marking is the duty of the tool *provider*. Ana's duties are those of a *deployer*.
- Do not cite the AI Act in a journal declaration, and do not use Elsevier's template on teaching materials.

---

## Track 1: EU AI Act disclosure for teaching materials

Regulation (EU) 2024/1689. Article 50 has applied since 2 August 2026. Goal: never under-disclose where the law requires it, and never overstate the law where materials are exempt.

### Workflow
1. Identify the content type (ask if unclear).
2. Diagnose legal status with the table; state in 2-4 sentences whether disclosure is *required* or *voluntary*, and which article applies.
3. Generate the note in English, with the Spanish equivalent, in the right length.
4. Adapt to format: footnote (PDF/doc), final slide or corner credit (deck), credits page (Moodle/Canvas/Chamilo/Articulate Rise), spoken or show-notes line (audio).

### Diagnosis table

| Situation | Status | Basis |
|---|---|---|
| Text drafted with AI, then reviewed, edited and approved by Ana (worksheets, lesson plans, exercises, scripts) | Exempt, voluntary note (human-review carve-out; teaching materials are generally not text informing the public on matters of public interest) | Art. 50(4), 2nd subpara. + exception |
| AI-generated images, audio or video that look or sound real | Disclose if it is a deepfake (resembles real persons, places or events and could appear authentic). Marking is the provider's duty | Art. 50(4); 50(2) is the provider's |
| Cloned voice or video avatar of Ana or anyone real delivering a lesson | Disclosure REQUIRED, clear at first exposure | Art. 50(4) + 50(5) |
| Chatbot students interact with | Disclosure REQUIRED unless obviously AI to a reasonably informed person; label the interface itself | Art. 50(1) + 50(5) |
| Obviously artistic, cartoon or fictional AI illustrations | Exempt, voluntary note | Art. 50(4) exceptions |
| LinkedIn or social posts showcasing her AI-assisted work | No legal label needed; use the methodology block (template E) | Art. 50(4) exception |

### Identity line
Default: **Ana Eslava-Graterol**, EFL teacher & instructional designer, registered self-employed professional (*autónoma*) in Spain.
Spanish: **Ana Eslava-Graterol**, docente de inglés y diseñadora instruccional, profesional autónoma registrada en España.
If a client requires anonymity, use "the instructional designer" but keep "registered self-employed professional in Spain", which anchors editorial responsibility to an identifiable legal person.

### Note templates
Adapt tone and learner level; keep article citations exact. "¹" stands for the document's footnote marker.

**A. AI-assisted, human-edited text (voluntary)**

English, full:
> ¹ *Transparency note:* This educational material was developed with the assistance of generative AI tools. All content has been reviewed, adapted and approved by Ana Eslava-Graterol, EFL teacher & instructional designer, registered self-employed professional (*autónoma*) in Spain, who assumes full editorial responsibility, in the spirit of Article 50 of the EU Artificial Intelligence Act (Regulation (EU) 2024/1689).

English, standard:
> ¹ Developed with the assistance of generative AI. Reviewed, edited and approved under the editorial responsibility of Ana Eslava-Graterol, instructional designer registered as a self-employed professional in Spain (EU AI Act, Art. 50).

English, ultra-short:
> ¹ AI-assisted material · human-edited & verified · A. Eslava-Graterol, Spain · EU AI Act Art. 50

Spanish, standard:
> ¹ Elaborado con asistencia de IA generativa. Revisado, editado y aprobado bajo la responsabilidad editorial de Ana Eslava-Graterol, diseñadora instruccional y profesional autónoma registrada en España (Reglamento (UE) 2024/1689 — Ley de IA, art. 50).

**B. Fully AI-generated realistic images, audio or video**

English, full:
> ¹ *AI-generated content:* The [images / audio / video] in this lesson were artificially generated. Disclosed in accordance with Article 50(4) of the EU Artificial Intelligence Act. Selected and verified for pedagogical accuracy by Ana Eslava-Graterol, EFL teacher & instructional designer, registered self-employed professional (*autónoma*) in Spain.

English, ultra-short:
> ¹ AI-generated [image/audio] · disclosed under EU AI Act Art. 50(4)

Spanish, standard:
> ¹ Contenido generado por IA: [las imágenes / el audio] de esta lección se han generado artificialmente, conforme al artículo 50(4) de la Ley de IA de la UE. Selección y verificación pedagógica: Ana Eslava-Graterol, profesional autónoma registrada en España.

**C. Cloned voice or avatar (mandatory, prominent)**
Must be clear and distinguishable at first exposure (Art. 50(5)); a footnote alone is not enough. Show or say it before the content starts, and repeat it in the credits.

English:
> This lesson is presented by an AI-generated avatar / synthetic voice of Ana Eslava-Graterol. Disclosed in accordance with Articles 50(4) and 50(5) of the EU Artificial Intelligence Act. Content authored and verified by Ana Eslava-Graterol, registered self-employed professional in Spain.

Spanish:
> Esta lección se presenta mediante un avatar generado por IA / una voz sintética de Ana Eslava-Graterol, conforme a los artículos 50(4) y 50(5) de la Ley de IA de la UE. Contenido creado y verificado por Ana Eslava-Graterol, profesional autónoma registrada en España.

**D. Chatbot label (mandatory, on the interface)**

English: "You are chatting with an AI practice assistant, not a human teacher (EU AI Act, Art. 50(1)). Your teacher, Ana Eslava-Graterol, reviews the activities it is based on."

Spanish: "Estás conversando con un asistente de práctica basado en IA, no con una persona (Ley de IA de la UE, art. 50(1))."

**E. LinkedIn and social posts (methodology block, no disclaimer)**
LinkedIn does not render Markdown. Deliver plain text ready to paste: real line breaks, the bullet character "•", no asterisks or Markdown. English first, then Spanish.

English (adapt the first line):
> [Pedagogical goal, e.g. "I designed this B2 Reading unit for Cambridge exam preparation..."]
>
> ⚙️ Design methodology:
> • Curation: content and pedagogical structure selected using my professional teaching judgement.
> • Co-creation: AI used as an assistant to refine wording and generate activity ideas.
> • Quality control: editing, bias review and content validation 100 % human.

Spanish:
> [Objetivo pedagógico, p. ej. "Diseñé esta unidad B2 de Reading para preparación Cambridge..."]
>
> ⚙️ Metodología de diseño:
> • Curación: información y estructura pedagógica seleccionadas bajo mi criterio docente.
> • Co-creación: IA como asistente para optimizar la redacción y generar ideas de actividades.
> • Control de calidad: edición, revisión de sesgos y validación de contenidos 100 % humana.

### Choosing a length
- Full: course credit pages, client deliverables, anything a compliance team might read.
- Standard: worksheets, PDFs, teacher guides (default).
- Ultra-short: slide corners, infographics, social posts, Canva designs.

### Track 1 output
Deliver the note ready to paste (English first, then Spanish), then the 2-4 sentence status explanation. If she is finalising a document in this session, offer to insert the note (footer, final slide or credits page). Match formatting to destination; plain text for social platforms.

---

## Track 2: Elsevier AI policy for journal manuscripts

Source: Elsevier "Generative AI policies for journals" (authors section). The policy evolves, so for a real submission tell Ana to confirm against the current Elsevier page and the target journal's Guide for Authors.

### Core principles
1. AI may support tasks (literature synthesis, field overviews, gap identification, ideas, organization, language and readability), never replace human critical thinking, expertise and evaluation.
2. Human oversight and control; authors are accountable for all content.
3. Verify accuracy, comprehensiveness and impartiality of all AI output, and check every source (AI references can be fabricated).
4. Edit and adapt so the text reflects the author's own analysis, interpretation and ideas.
5. Be transparent: disclosure statement at submission.
6. Safeguard data privacy, IP and other rights.

### Classify the use

| Use | Disclosure | Where |
|---|---|---|
| Basic grammar, spelling, punctuation checks | Not required | n/a |
| AI makes substantive changes to sentence structure or organization | Required | AI declaration statement |
| Drafting, synthesizing, rewriting or brainstorming with AI during manuscript preparation | Required | AI declaration statement |
| AI inside specialist disability-related assistive technology, solely for accessibility | Not required | n/a |
| AI used as part of the research process (analysis, coding, imaging, modelling) | Required, in detail | Methods section (reproducible: tool/model name, version, developer) |
| Explanatory images made with AI (flow charts, decision trees, timelines, schematics) | Required | Caption of each image (tool, version, how used) + general declaration |
| Data visualizations supported by AI | Required | Methods section (name, version, developer); output must derive directly from the data via reproducible methods |
| Primary research images created or altered by AI | Not allowed | n/a |
| Graphical abstract made with a general-purpose generative image tool | Not allowed (use dedicated scientific illustration tools) | n/a |
| Journal cover art made with AI | Only with prior permission from editor and publisher | n/a |

### Hard limits
- AI must not be listed or cited as author or co-author.
- No fabricating or altering data, results or figures not faithfully derived from the underlying data.
- No AI creation or alteration of primary observed or experimental images (microscopy, blots, scans, patient images); even brightness, contrast or color changes must use established image-processing software.
- No images that duplicate or refer to existing copyrighted images, real people, identifiable products or brands, and no likeness of an individual's voice.

### Check the tool's terms
Confirm that privacy and confidentiality of inputs (including unpublished manuscripts and personal data) are maintained; the tool gets only the right to use material to provide the service, with no right to train on it; and it does not restrict later publication of outputs.

### Draft the disclosure

Manuscript preparation (separate section in the manuscript at submission; appears in the published article):

Title of section: Declaration of generative AI and AI-assisted technologies in the manuscript preparation process

Statement: During the preparation of this work, the author(s) used [NAME OF TOOL / SERVICE] in order to [REASON]. After using this tool/service, the author(s) reviewed and edited the content as needed and take(s) full responsibility for the content of the published article.

Good practice: name the tool and version, the purpose, and the extent of human oversight.

Explanatory image caption add-on: "Created with [tool, version] to [how it was used]; reviewed and verified by the authors." Also mention it in the general declaration.

Methods paragraph (AI in research or data visualization): tool or model name, version, developer, the task, and enough detail to reproduce the workflow; note adherence to the tool's usage policy and attribution where required.

### Pre-submission checklist
- [ ] Every AI output verified; every reference checked against the real source
- [ ] Text edited so it carries my own analysis and voice
- [ ] Declaration statement added in its own section (if required)
- [ ] Image captions and Methods sections carry tool, version, developer where needed
- [ ] No AI listed or cited as author
- [ ] Tool terms checked (privacy, no training rights, no output restrictions)
- [ ] No restricted image uses
- [ ] Confirmed against the target journal's current Guide for Authors

### Track 2 output
Verdict first (allowed / allowed with disclosure / not allowed), then the ready-to-paste text. Concise; flag uncertainty instead of guessing. For a full manuscript audit before submission, point to the gateguardian skill.