---
name: ux-writing-attribution
description: Internal reference for the training provenance, attribution wording, and responsible use of the UX Writing guide's source material.
---

# Atribución formativa de la guía de UX Writing

Esta referencia documenta la procedencia formativa y los límites de atribución de la guía de UX Writing de CUXedTech. Para la formulación completa, los datos compartidos durante la sesión y las condiciones de uso, consulta `../ux-writing-travel-good/references/atribucion-formativa.md`.

Nombre y cargo que deben utilizarse: **Antonio Estévez Funes, Conversational Designer en BBVA**. Contexto: masterclass, curso y charla impartidos el 6 de noviembre de 2026 en la Escuela de Diseño Instruccional de la Universitat Politècnica de València (UPV).

No atribuyas al ponente, a BBVA ni a la UPV la autoría, revisión, aprobación o respaldo de la guía o del plugin. Distingue los aprendizajes compartidos durante la sesión de la síntesis, organización y adaptación didáctica desarrolladas para CUXedTech.
