# CUXedTech reusable templates

## Finding record
- ID:
- Dimension / criterion:
- Page, screen, component or journey:
- Observation:
- Evidence source:
- Evidence status: Observed / Evidence-supported / Hypothesis / Unknown
- User impact:
- Severity and rationale:
- Recommendation:
- Dependencies / specialist:
- Validation method:
- Acceptance criteria:

## Wireframe handoff
- Screen name and purpose:
- Primary user and task:
- Entry point:
- Exit / next step:
- Content hierarchy:
- Component inventory:
- Interaction behaviour:
- Empty / loading / error / success states:
- Responsive behaviour:
- Language behaviour:
- Theme behaviour:
- Accessibility requirements:
- Assumptions / open questions:

## UX evaluation report
1. Executive summary
2. Product and user context
3. Scope and methods
4. Key findings
5. Findings by dimension
6. Accessibility
7. Responsive and device experience
8. Multilingual experience
9. Visual identity and design system
10. Positive patterns to preserve
11. Prioritised recommendations
12. Dependencies and specialist review
13. Validation plan
14. Acceptance criteria
15. Open questions and assumptions

## Evidence discipline
Never present an assumption as an observed fact. Never claim user testing, technical inspection, accessibility conformance or implementation unless performed and evidenced.
