# Ocean Ink — Colour ramps and instructional states

Ten steps per hue. Steps 50–200 are tints for backgrounds; 600–900 are text-safe on light backgrounds. Named brand values: **blue-500**, **gold-400**, **rose-500**.

## Blue — primary

| Step | Hex | Typical use |
|---|---|---|
| 50 | #EEF2FD | Tinted background, table stripe |
| 100 | #DCE4FB | Chips, A1 level |
| 200 | #B9C8F6 | A2 level, dark-theme headings |
| 300 | #8FA5EE | B1-adjacent tints; dark-theme link is #9DB2FF |
| 400 | #6480E3 | B1 level, chart series |
| 500 | #3B5BD6 | **Primary** — buttons, links, active states, focus ring |
| 600 | #3049AE | C1 level, hover on primary |
| 700 | #22307C | **Deep blue** — headings on light, C2, gradient end |
| 800 | #1A2560 | Depth accents |
| 900 | #131A44 | on-primary (dark theme), deepest depth |

## Gold — accent

| Step | Hex | Typical use |
|---|---|---|
| 50 | #FDF6EA | Attention-banner tint, XP chip bg |
| 100 | #FAE9CC | Soft highlight bg |
| 200 | #F4D69F | Tints |
| 300 | #EEC272 | Dark-theme accent & attention |
| 400 | #E8A33D | **Accent** — fills, large text, one per screen |
| 500 | #C9871F | Hover on accent fills |
| 600 | #9A5B00 | **Gold-as-text** on light (5.11:1) |
| 700 | #7A4700 | Darker text accent |
| 800 | #5C3500 | Dark XP chip bg |
| 900 | #3D2300 | Deepest |

## Rose — progress (instructional tier ONLY)

| Step | Hex | Typical use |
|---|---|---|
| 50 | #FBF0F3 | Correct-banner tint |
| 100 | #F6DFE5 | Soft bg |
| 200 | #EBBECA | Tints |
| 300 | #DC93A8 | Dark-theme progress fill approx (#E0A6B8 canonical) |
| 400 | #C56A85 | Chart series |
| 500 | #8B3A52 | **Rose** — progress, confirmation, correct (light) |
| 600 | #783045 | Hover |
| 700 | #612738 | Text on tints |
| 800 | #4A1D2B | Depth |
| 900 | #33141E | Deepest |

Rose never appears in the identity tier. It means progress, nothing else.

## Four instructional states

Each ships with glyph + label so meaning survives greyscale, colour-blindness and print.

| Token | Meaning | Glyph | Light | Dark |
|---|---|---|---|---|
| `state-correct` | Correct, complete, mastered | ✓ | #8B3A52 | #E0A6B8 |
| `state-attention` | Needs review — never "wrong" | ! | #9A5B00 | #EEC272 |
| `state-active` | In progress, current step | ▸ | #3B5BD6 | #9DB2FF |
| `state-locked` | Not yet available | ○ | #5B5F77 | #A6ADC8 |

Wording matters pedagogically: attention copy says "worth another look / requiere revisión", never "wrong / incorrecto".

## CEFR level scale

One hue (blue), six steps, read as depth — not six unrelated colours. Label always accompanies the swatch.

A1 #DCE4FB · A2 #B9C8F6 · B1 #6480E3 · B2 #3B5BD6 · C1 #3049AE · C2 #22307C

On A1/A2 (light swatches) use deep-blue text #22307C; from B1 up use white text.

## Measured contrast (reference)

Light theme: ink/canvas 15.53:1 AAA · muted/canvas 5.91:1 AA · primary/white 5.75:1 AA · white/primary 5.75:1 AA · deep-blue/canvas 11.11:1 AAA · gold-600/canvas 5.11:1 AA · rose/white 7.43:1 AAA.

Dark theme: ink/canvas 16.46:1 AAA · muted 8.41:1 AAA · primary #9DB2FF 9.14:1 AAA · gold #EEC272 8.68:1 AAA · rose #E0A6B8 9.86:1 AAA.
