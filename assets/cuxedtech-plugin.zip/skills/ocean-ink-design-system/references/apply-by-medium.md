# Ocean Ink — Applying the system per medium

The tokens live in `assets/ocean-ink.css` for the web. Everything else maps the same names to fixed hex values per theme. Default to the **light theme** for print and documents; build dark variants from the dark column, never by inverting.

## §Documents — Word (.docx) and PDF

Use with the docx/pdf skills (they handle the file mechanics; this section supplies the design).

- Page background: white #FFFFFF (print-friendly stand-in for canvas). For digital-only PDFs, canvas #F7F8FC is allowed.
- H1–H2 ("Heading 1/2" styles): Fraunces 600–700 — if Fraunces is unavailable in the pipeline, embed it (Google Fonts) or fall back to Georgia. Colour #22307C.
- H3 and below: Inter 600, #1C1E2E.
- Body: Inter 400, 11pt, #1C1E2E, line spacing ≈1.5; secondary text #5B5F77.
- Links: #3B5BD6, underlined.
- Accent use: one gold element per page maximum. Gold text at body size must be #9A5B00.
- Tables: header row fill #EEF2FD with #22307C text; borders #E6E8F2; no pure-grey fills.
- Callout/quote blocks: 3–4pt left border in a state colour + glyph + label, background tint from the matching 50-step.
- Never use red for warnings; use #9A5B00 with "!" and a "needs review"-style label.

## §Slides — PowerPoint (.pptx), Google Slides

- Light deck: canvas #F7F8FC, cards #FFFFFF with #E6E8F2 hairlines.
- Dark deck: canvas #0F1120, cards #171A2B, hairlines #2A2D44 — use the dark token column throughout (headings #B9C8F6, body #EEF0F8, muted #A6ADC8, links #9DB2FF).
- Titles: Fraunces 700; light decks #22307C, dark decks #B9C8F6 or #FFFFFF.
- Body: Inter; minimum 18pt on slides.
- Hero/section-divider slides: signature gradient 135° #3B5BD6→#E8A33D, max one band per slide, white Fraunces display text on top, no body text on the gradient.
- One gold accent per slide (a number, a key phrase, a shape) — not several.
- Charts on slides follow §Charts.

## §Charts and data visualization

Also read the `dataviz` skill if available — then swap its placeholder palette for these values.

- Categorical series order (light): blue-500 #3B5BD6 · gold-400 #E8A33D · rose-500 #8B3A52 · blue-700 #22307C · gold-600 #9A5B00 · rose-300 #DC93A8.
- Categorical series order (dark): #9DB2FF · #EEC272 · #E0A6B8 · #B9C8F6 · #C9871F · #C56A85.
- Sequential ramps: use one hue's 100→700 steps (blue for neutral quantities, rose for progress metrics).
- Grid lines #E6E8F2 (light) / #2A2D44 (dark); axis text --muted; no pure black/grey.
- Never encode meaning by colour alone: direct-label series or add markers/patterns; progression uses depth of one hue, not a rainbow.
- Progress/success indicators: rose, with a ✓ or percentage label. "Needs review" marks: gold, with "!". Never red.

## §Spreadsheets (.xlsx)

- Header rows: fill #22307C, white Inter 600 text (or fill #EEF2FD with #22307C text for a lighter look).
- Banded rows: #F7F8FC / #FFFFFF; borders #E6E8F2.
- Conditional formatting: correct/on-track = rose tint #FBF0F3 + ✓; needs review = gold tint #FDF6EA + "!"; active = blue tint #EEF2FD. Never the default red/green scales.

## §Design-tools — Canva, Adobe Express, Figma

When creating a brand kit, template, or when writing a prompt/brief for these tools, state the system explicitly:

- Brand colours: primary blue #3B5BD6, deep blue #22307C, gold #E8A33D (accents only), rose #8B3A52 (progress only), canvas #F7F8FC, ink #1C1E2E. Dark set: canvas #0F1120, surface #171A2B, text #EEF0F8, blue #9DB2FF, gold #EEC272, rose #E0A6B8.
- Fonts: Fraunces (headings) + Inter (body/UI) — both on Google Fonts, available natively in Canva and Express.
- Rules to include verbatim in any brief: "one gold accent per screen; errors/warnings in amber, never red; no pure black or pure grey; dark version uses its own palette, not an inversion; gradient #3B5BD6→#E8A33D at 135° only in hero headers, once per page."
- For Figma: create colour styles/variables named exactly like the tokens (ink, canvas, surface, line, muted, primary, primary-deep, on-primary, accent, accent-text, success, focus-ring) with light and dark modes.

## §E-learning platforms — Moodle, Chamilo, Articulate Rise, Canvas LMS

- Rise/LMS theme colour: #3B5BD6; hover/secondary #3049AE.
- Feedback blocks: use the four instructional states with glyph + label ("Correct — you used the chunk in context" style phrasing; Spanish: "Correcto — usaste el chunk en contexto").
- Progress bars and completion: rose, labelled with %.
- Where custom CSS is allowed (Moodle/Chamilo), paste `assets/ocean-ink.css`.
- CEFR badges: blue-ramp scale with the level label always visible (A1 #DCE4FB … C2 #22307C).
