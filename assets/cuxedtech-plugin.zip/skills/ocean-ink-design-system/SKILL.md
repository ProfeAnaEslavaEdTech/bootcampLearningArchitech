---
name: ocean-ink-design-system
description: Apply Ana Eslava-Graterol's Ocean Ink design system — her WCAG 2.1 AA-verified brand palette (indigo blue, warm gold, rose) with paired light AND dark themes, plus Fraunces + Inter typography — to every visual deliverable. Use this skill whenever creating ANYTHING visual for Ana, including HTML pages, artifacts, dashboards, presentations (pptx), Word documents, PDFs, infographics, charts, data visualizations, e-learning screens, social graphics, email templates, or prompts/specs for Canva, Adobe Express or Figma. Trigger even if she doesn't mention the palette by name — phrases like "hazlo con mi diseño", "mi paleta", "my brand", "Ocean Ink", "dark and light", "con mis colores", or simply any request to design or style something, mean this system applies. Do NOT invent new brand colors when this skill is available.
---

# Ocean Ink Design System

Ana's single visual identity across website, portfolio, LinkedIn, CV, Instagram, courses and apps. Every value below is **measured against WCAG 2.1 AA** (4.5:1 body text, 3:1 large text and UI). Copy is primarily English, sometimes Spanish — no colour or type choice may depend on text length.

The system has two tiers:

- **Identity tier** — quiet, classic, minimal. Blue + gold on tinted neutrals. Used for anything that represents Ana herself (portfolio, CV, LinkedIn banners, site pages).
- **Instructional tier** — functional colours with fixed meanings (correct / attention / active / locked, plus rose = progress). Used inside learning content, courses, feedback UI.

## Seven foundational rules

1. Two tiers: identity vs instructional. Rose and the four state colours belong ONLY to the instructional tier.
2. Colour never carries meaning alone — always pair it with an icon/glyph, a label, or position (WCAG 1.4.1). Meaning must survive greyscale and print.
3. Dual theme by default: every token has a light value and a dark value. Never invert one theme to produce the other — use the token table.
4. One accent at a time. One gold accent per screen, on the single thing you want acted on. Never split emphasis 50/50.
5. Neutrals are tinted (blue-shifted), never pure grey. Pure grey reads off-brand.
6. No pure black anywhere. Dark theme uses a deep tinted canvas (#0F1120) to avoid halation for astigmatic readers.
7. Errors are amber/gold ("needs review"), never red (affective filter — this is a pedagogical decision). Red is banned for errors everywhere in the system.

## Token table (ship names, not hex literals)

Declare the light set on `:root` and the dark set under `[data-theme="dark"]`. A ready-made stylesheet with all tokens, fonts and base components is in `assets/ocean-ink.css` — copy it into HTML deliverables instead of retyping values.

| Token | Light | Dark |
|---|---|---|
| `--ink` (body text) | #1C1E2E | #EEF0F8 |
| `--canvas` (page bg) | #F7F8FC | #0F1120 |
| `--surface` (cards) | #FFFFFF | #171A2B |
| `--line` (borders) | #E6E8F2 | #2A2D44 |
| `--muted` (secondary text) | #5B5F77 | #A6ADC8 |
| `--primary` (links, active) | #3B5BD6 | #9DB2FF |
| `--primary-deep` (headings) | #22307C | #B9C8F6 |
| `--on-primary` (text on primary fill) | #FFFFFF | #131A44 |
| `--accent` (gold, fills/large only) | #E8A33D | #EEC272 |
| `--accent-text` (gold at body size) | #9A5B00 | #EEC272 |
| `--success` (rose) | #8B3A52 | #E0A6B8 |
| `--focus-ring` | #3B5BD6 | #9DB2FF |

Key nuances:

- **Headings**: blue-700 (#22307C) on light, blue-300 (#B9C8F6/#9DB2FF family) on dark.
- **Primary in dark theme**: text/links shift to blue-300 #9DB2FF (9.14:1). Button **fills** keep blue-500 #3B5BD6 with white text in both themes.
- **Gold at body size on light backgrounds fails contrast** — use gold-600 #9A5B00 instead. Gold #E8A33D is only for fills, large text, and dark backgrounds.
- **Signature gradient**: linear-gradient(135deg, #3B5BD6, #E8A33D). Heroes/header bands only — maximum one per page, never behind body text.

## Colour ramps (ten steps per hue)

Full ramps for tints, hovers, and charts are in `references/ramps-and-states.md`. Named brand values: **blue-500 #3B5BD6**, **gold-400 #E8A33D**, **rose-500 #8B3A52**. Steps 50–200 are background tints; 600–900 are text-safe on light.

## Instructional tier — four states + CEFR scale

Each state ships with a glyph AND a label (meaning survives greyscale, colour-blindness, print):

| State | Meaning | Glyph | Light | Dark |
|---|---|---|---|---|
| state-correct | Correct, complete, mastered | ✓ | #8B3A52 | #E0A6B8 |
| state-attention | Needs review — never "wrong" | ! | #9A5B00 | #EEC272 |
| state-active | In progress, current step | ▸ | #3B5BD6 | #9DB2FF |
| state-locked | Not yet available | ○ | #5B5F77 | #A6ADC8 |

CEFR level scale — one hue, six steps of the blue ramp, read as depth (label always accompanies the swatch): A1 #DCE4FB · A2 #B9C8F6 · B1 #6480E3 · B2 #3B5BD6 · C1 #3049AE · C2 #22307C.

## Typography — Fraunces + Inter (both on Google Fonts)

Works identically in Canva, Articulate Rise, Moodle, Chamilo, Google Sites and web builds; never depend on a locally installed font.

- **Fraunces** 600–700 → display, H1–H2. Carries the classic, senior register.
- **Inter** 400–700 → H3, UI, body, kickers/overlines (letter-spaced caps in primary blue).
- Mobile-native scale: body 17px/1.6, H1 28–32px, H2 22px, tap targets ≥ 44×44px.
- Responsive scale: body 15–16px/1.6, H1 clamp 26–38px, H2 22px, body max-width ≈65ch.
- No hover-dependency, no side-by-side comparisons, no scrollable tables on mobile.

## Accessibility checklist (verify before delivering)

- Body text ≥ 4.5:1 against its background; large text and UI ≥ 3:1. The token pairs above are pre-measured (light: ink/canvas 15.53:1, primary/white 5.75:1, gold-600/canvas 5.11:1; dark: primary 9.14:1, gold 8.68:1) — stick to them and contrast passes automatically.
- Focus ring: 3px `--focus-ring` outline, 2px offset, on every interactive element.
- Every state colour paired with glyph + label.
- Charts and progress: never colour-only encoding; add labels, patterns or position.
- Dark theme built from the dark token column, never by inverting.

## Applying per medium

For medium-specific recipes, read the matching reference before building:

- **HTML / artifacts / dashboards / e-learning screens** → start from `assets/ocean-ink.css` (tokens, fonts, buttons, feedback banners, hero band, dark-mode toggle pattern). Charts and dataviz: `references/apply-by-medium.md` §Charts.
- **Word / PDF / PowerPoint / spreadsheets** → `references/apply-by-medium.md` §Documents and §Slides (hex mappings for heading/body/accent styles, since Office has no CSS tokens). Combine with the docx/pptx/pdf/xlsx skills — those handle the file mechanics, this skill supplies the design.
- **Canva, Adobe Express, Figma prompts or specs** → `references/apply-by-medium.md` §Design-tools (how to state the palette, fonts and rules inside a brief or brand-kit setup).

## Do & don't

Do: one gold accent per screen · glyph + label with every state colour · blue-700 headings on light, blue-300 on dark · gradient only in hero bands, one per page.

Don't: gold at body size on light (use #9A5B00) · rose in the identity tier (it means progress, nothing else) · red for errors, anywhere · inverting light theme to get dark · pure grey or pure black · colour as the only signal.
- **New tab/window = visible cue (WCAG 3.2.5).** Any link or button that opens in a new tab or window carries a visible label saying so — e.g. `Go to Lesson 7 (opens in a new tab) →` / `Ir a la Lección 7 (abre en pestaña nueva) →` (the cue may be smaller/lighter but must be visible, not just `title`/`aria`). Pair with `target="_blank"` and `rel="noopener"`. Applies to e-learning buttons, document/PDF links and all external links. Never open a new tab silently.